AMOUNT_OF_ROUNDS = 3
EVEN_INSTRUCTION = "Пользователю даётся число и ему нужно ответить чётное оно или нет"