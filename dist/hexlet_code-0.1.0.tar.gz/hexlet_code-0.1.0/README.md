### Hexlet tests and linter status:
[![Actions Status](https://github.com/OlegGordienko/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/OlegGordienko/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/2883eb6d07dc1dabfc27/maintainability)](https://codeclimate.com/github/OlegGordienko/python-project-49/maintainability)

## Run game Even
[![asciicast](https://asciinema.org/a/3A7KmGaPhohoGE9NuUcJJyF7c.svg)](https://asciinema.org/a/3A7KmGaPhohoGE9NuUcJJyF7c)
